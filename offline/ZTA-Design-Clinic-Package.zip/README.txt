ZTA Design Clinic - Integrated Document Package
================================================

Open index.html in a browser to navigate everything. Every document is a
self-contained HTML file (opens offline) and is also provided as a PDF in /pdf.
Each HTML page has a "Print / Save as PDF" button.

CONTENTS
--------
Give to teams (participant-facing):
  ZTA-Participant-Steps.pptx
                       A one-slide, step-by-step guide for teams: understand the
                       customer pain points, agree the Cisco solution and record it
                       in the Workbook, draw the logical diagram on the flip chart,
                       loop through every use case, review with the SME, digitize
                       with Cisco Circuit, and submit. Editable PowerPoint; a PDF
                       copy is in /pdf.
  activity-guide.html  ZTA Design Clinic Activity Document
                       Customer, environment, roles, the Segmentation Cycle,
                       learning objectives, a 60-minute timeline, a Cisco product
                       primer, each use case's requirements, pain points and
                       tasks, and a glossary. No answers.
  workbook.html        ZTA Design Clinic Workbook
                       Team answer sheet: per use case a large diagram space,
                       pain-point and requirement tables to complete, a
                       suggested-products table (names pre-filled), and a proctor
                       score box (out of 100). Ends with a Final Score & Group
                       Level page: each use case score, cumulative totals, the
                       awarded group level, and overall feedback. Glossary.

Proctor only (do not share with participants during the event):
  solution-guide.html  ZTA Design Clinic Solution Guide
                       Reference answers per use case (pain-point responses,
                       requirement responses, expected products), the Segmentation
                       Cycle mapped to the use cases, each use case's proposed
                       final design, "what to reward" notes, and a glossary.
                       Proctor-only during the event; a participant learning
                       reference afterwards.
  grading-guide.html   ZTA Design Clinic Grading Guide
                       How to grade: the Mapping/Products/Diagram rubric (each use
                       case out of 100), the cumulative group-level model and
                       thresholds, what a strong answer looks like per use case,
                       SME verification questions, a scoring workflow, and a team
                       scoresheet with cumulative totals and level award.
  grading-prompt.html  ZTA Design Clinic AI Grading Prompt
                       A tool-agnostic prompt (Claude / ChatGPT / Gemini). Paste
                       it into any AI assistant, attach a team's completed
                       Workbook, and it returns per use case scores, cumulative
                       totals and the group level using this clinic's rubric. The
                       raw prompt is also in grading-prompt.txt for easy copy.
  grading-prompt.txt   The raw AI Grading Prompt as plain text (copy/paste).
  ZTA-Proctor-Playbook.pptx
                       A 3-slide briefing for proctors on how to run the group
                       activity and engage participants: the 60-minute flow and
                       setup, coaching moves (guide, don't solve), and how to
                       score, level and close. Editable PowerPoint; a PDF copy is
                       in /pdf.

PDFs (/pdf): ZTA-Participant-Steps.pdf, ZTA-Activity-Guide.pdf, ZTA-Workbook.pdf,
             ZTA-Solution-Guide.pdf, ZTA-Grading-Guide.pdf,
             ZTA-AI-Grading-Prompt.pdf, ZTA-Proctor-Playbook.pdf

NOTES
-----
- Scoring: each use case is scored out of 100 (Mapping 40 / Products 30 /
  Diagram 30). The Associate / Professional / Expert level is CUMULATIVE for the
  whole group, not per use case:
    * Associate    - all three required use cases (UC1-UC3), cumulative under 70%.
    * Professional - all three required use cases, cumulative 70% or higher
                     (a perfect three-use-case result is Professional).
    * Expert       - all five use cases attempted, cumulative 80% or higher.
  These levels are a facilitation framework; calibrate with an SME.
- The UC5 "addressing pain points" answers were corrected from a copy-paste error
  in the source SME Solution Guide (see the note on that page).
