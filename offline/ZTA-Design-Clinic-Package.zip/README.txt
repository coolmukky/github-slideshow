ZTA Design Clinic - Integrated Document Package
================================================

Open index.html in a browser to navigate everything. Every document is a
self-contained HTML file (opens offline) and is also provided as a PDF in /pdf.
Each HTML page has a "Print / Save as PDF" button.

CONTENTS
--------
Give to teams (participant-facing):
  activity-guide.html  ZTA Design Clinic Activity Document
                       Customer, environment, roles, the Segmentation Cycle,
                       learning objectives, a 60-minute timeline, a Cisco product
                       primer, each use case's requirements, pain points and
                       tasks, and a glossary. No answers.
  workbook.html        ZTA Design Clinic Workbook
                       Team answer sheet: per use case a diagram space, pain-point
                       and requirement tables to complete, a suggested-products
                       table (names pre-filled), and a proctor per-use-case score
                       and feedback grid. Ends with a Final Score & Group Level
                       page (each use case score, cumulative totals, and the
                       awarded group level). Glossary.

Proctor only (share with participants only AFTER the event):
  solution-guide.html  ZTA Design Clinic Solution Guide
                       Reference answers per use case (pain-point responses,
                       requirement responses, expected products), the Segmentation
                       Cycle mapped to the use cases, each use case's proposed
                       final design, "what to reward" notes, and a glossary.
                       Proctor-only during the event; a participant learning
                       reference afterwards.
  grading-guide.html   ZTA Design Clinic Grading Guide
                       How to grade: the Mapping/Products/Diagram rubric (each use
                       case out of 100), the cumulative group-level model and
                       thresholds, what a strong answer looks like per use case,
                       SME verification questions, a scoring workflow, and a team
                       scoresheet with cumulative totals and level award.

PDFs (/pdf): ZTA-Activity-Guide.pdf, ZTA-Workbook.pdf, ZTA-Solution-Guide.pdf,
             ZTA-Grading-Guide.pdf

NOTES
-----
- Scoring: each use case is scored out of 100 (Mapping 40 / Products 30 /
  Diagram 30). The Associate / Professional / Expert level is CUMULATIVE for the
  whole group, not per use case:
    * Associate    - all three required use cases (UC1-UC3), cumulative under 70%.
    * Professional - all three required use cases, cumulative 70% or higher
                     (a perfect three-use-case result is Professional).
    * Expert       - all five use cases attempted, cumulative 80% or higher.
  These levels are a facilitation framework; calibrate with an SME.
- The UC5 "addressing pain points" answers were corrected from a copy-paste error
  in the source SME Solution Guide (see the note on that page).
