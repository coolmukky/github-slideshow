ZTA Design Clinic - Integrated Document Package
================================================

Open index.html in a browser to navigate everything. Every document is a
self-contained HTML file (opens offline) and is also provided as a PDF in /pdf.
Each HTML page has a "Print / Save as PDF" button.

CONTENTS
--------
Give to teams (participant-facing):
  activity-guide.html  ZTA Design Clinic Activity Document
                       Customer, environment, roles, the Segmentation Cycle,
                       learning objectives, a 60-minute timeline, a Cisco product
                       primer, each use case's requirements, pain points and
                       tasks, and a glossary. No answers.
  workbook.html        ZTA Design Clinic Workbook
                       Team answer sheet: per use case a diagram space, pain-point
                       and requirement tables to complete, a suggested-products
                       table (names pre-filled), and a proctor score, level and
                       feedback grid. Glossary.

Proctor only (share with participants only AFTER the event):
  solution-guide.html  ZTA Design Clinic Solution Guide
                       Reference answers per use case (pain-point responses,
                       requirement responses, expected products), the Segmentation
                       Cycle mapped to the use cases, each use case's proposed
                       final design, "what to reward" notes, and a glossary.
                       Proctor-only during the event; a participant learning
                       reference afterwards.
  grading-guide.html   ZTA Design Clinic Grading Guide
                       How to grade: proficiency levels, the Mapping/Products/
                       Diagram rubric, what a good answer looks like at each level
                       per use case, SME verification questions, a scoring
                       workflow, and a team scoresheet.

PDFs (/pdf): ZTA-Activity-Guide.pdf, ZTA-Workbook.pdf, ZTA-Solution-Guide.pdf,
             ZTA-Grading-Guide.pdf

NOTES
-----
- Scoring levels (Associate / Professional / Expert) and the "expected answer by
  level" text are a facilitation framework. Calibrate with an SME.
- The UC5 "addressing pain points" answers were corrected from a copy-paste error
  in the source SME Solution Guide (see the note on that page).
