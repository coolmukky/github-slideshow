ZERO TRUST ACCESS DESIGN CLINIC — Offline Document Package
==========================================================
Open index.html to start, or open any document directly. Self-contained: no
internet needed (diagram + styling embedded). Print / Save as PDF from any
HTML file, or use the ready-made PDFs in /pdf. Aligned to the official Cisco
attendee guide, Solution Guide and SME Cheat Sheet.

GIVE TO TEAMS
  activity-guide.html  Customer, environment, roles, methodology, use-case
                       briefs, and "How you'll be scored" (Associate /
                       Professional / Expert levels + rubric).
  workbook.html        Team answer sheet — for each use case: an "addressing
                       pain points" table, a "meeting requirements" table, the
                       SUGGESTED Cisco products to fill in (how & why), a
                       diagram space, plus a proctor score/level grid + feedback.

PROCTOR ONLY — DO NOT SHOW PARTICIPANTS
  solution-guide.html  The answers: pain-point responses, requirement
                       responses and expected products for every use case.
  grading-guide.html   How to grade: the three levels, criteria x level
                       rubric, expected answer at each level, score + feedback
                       sheet per use case.

pdf/                   A4 PDFs of all four documents.

Use cases: 1 Segmentation, 2 Remote-Worker Zero Trust Access, 3 AI Access &
Agent Controls (required); 4 Merger & Acquisition, 5 Multicloud Data Center
(bonus). Each scored /100 (Mapping 40 / Products 30 / Diagram 30).
